﻿using System;

namespace XoR
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;
            Console.WriteLine("Please Enter First value(a): ");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Please Enter Second value(b): ");
            b = Convert.ToInt32(Console.ReadLine());
            Swapping(a, b);
        }

        static void Swapping(int a, int b)
        {
            a = a ^ b;   
            b = a ^ b;       
            a = a ^ b;

            Console.WriteLine("After Swapping: ");
            Console.WriteLine("a = " + a);
            Console.WriteLine("b = " + b);
            Console.ReadKey();
        }
    }
}
