﻿using System;

namespace FunctionalOverView_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 10, i;
            int[] arr = { 50, 20, 95, 36, 62, 1, 100, 23, 60, 12 };
            Console.Write("Initial array is: ");
            for (i = 0; i < n; i++)
            {
                Console.Write(arr[i] + " ");
            }
            quickSort(arr, 0, n-1);
            Console.Write("\nSorted Array is: ");
            for (i = 0; i < n; i++)
            {
                Console.Write(arr[i] + " ");
            }
        }

        static public void quickSort(int[] A, int L, int R)
        {
            int P;
            if (L < R)
            {
                P = Partition(A, L, R);
                if (P > 1)
                {
                    quickSort(A, L, P - 1);
                }
                if (P + 1 < R)
                {
                    quickSort(A, P + 1, R);
                }
            }
        }


        static public int Partition(int[] arr, int left, int right)
        {
            int P;
            P = arr[left];
            while (true)
            {
                while (arr[left] < P)
                {
                    left++;
                }
                while (arr[right] > P)
                {
                    right--;
                }
                if (left < right)
                {
                    int temp = arr[right];
                    arr[right] = arr[left];
                    arr[left] = temp;
                }
                else
                {
                    return right;
                }
            }
        }
       
    }
}
