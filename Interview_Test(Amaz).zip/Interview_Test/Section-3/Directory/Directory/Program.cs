﻿using System;

namespace Directory
{
    class Program
    {

        static System.Collections.Specialized.StringCollection log = new System.Collections.Specialized.StringCollection();
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a Drive: ");
            string drive = Console.ReadLine();
            string driveName = drive + ":/";

            System.IO.DriveInfo di = new System.IO.DriveInfo(driveName);

            System.IO.DirectoryInfo rootDir = di.RootDirectory;
            WalkDirectory(rootDir);
            Console.WriteLine("****** Finished ******");
            Console.ReadKey();
        }

        static void WalkDirectory(System.IO.DirectoryInfo root)
        {
            System.IO.FileInfo[] files = null;
            System.IO.DirectoryInfo[] subDirs = null;

            try
            {
                files = root.GetFiles("*.*");
            }

            catch (UnauthorizedAccessException e)
            {
                log.Add(e.Message);
            }

            catch (System.IO.DirectoryNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }

            if (files != null)
            {
                foreach (System.IO.FileInfo fi in files)
                {
                    Console.WriteLine(fi.FullName);
                }
                subDirs = root.GetDirectories();

                foreach (System.IO.DirectoryInfo dirInfo in subDirs)
                {
                    WalkDirectory(dirInfo);
                }
            }
        }
    }
}
