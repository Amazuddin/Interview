﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace htmlTagChecker
{
    class Program
    {
        public static Stack<string> endhtmlTags = new Stack<string>();

        static void Main(string[] args)
        {
            bool isCorrect = true;

            Console.WriteLine("Please Enter Number Of Input(integer Value): ");
            int numberOfInput = Convert.ToInt32(Console.ReadLine());

            while (numberOfInput > 0)
            {
                Console.WriteLine("Please Enter Input: ");
                string input = Console.ReadLine();

                string htmlTag = "";

                for (int index = 0; index < input.Length; index++)
                {
                    if (input[index] == '<' && htmlTag == "")
                    {
                        htmlTag = input[index].ToString();
                    }
                    else if (input[index] == '/' && htmlTag == "<")
                    {
                        htmlTag = htmlTag + input[index];
                    }
                    else if (Char.IsLetter(input[index]) && Char.IsUpper(input[index]) && (htmlTag == "<" || htmlTag == "</"))
                    {
                        htmlTag = htmlTag + input[index];
                    }
                    else if (input[index] == '>' && htmlTag.Length >= 1 && htmlTag[0] == '<' && Char.IsLetter(htmlTag[1]))
                    {
                        htmlTag = htmlTag + input[index];
                        htmlTag = htmlTag.Insert(1, "/");
                        endhtmlTags.Push(htmlTag);
                        htmlTag = "";
                    }
                    else if (input[index] == '>' && htmlTag.Length >= 2 && htmlTag[0] == '<' && htmlTag[1] == '/')
                    {
                        htmlTag = htmlTag + input[index];
                        bool isEndText = (index == input.Length - 1) ? true : false;
                        isCorrect = CheckhtmlTag(htmlTag, isEndText);
                        htmlTag = "";
                        if (!isCorrect)
                        {
                            break;
                        }
                        continue;
                    }
                    else
                    {
                        htmlTag = "";
                        continue;
                    }
                }

                if (isCorrect)
                {
                    Console.WriteLine("Correctly tagged paragraph");
                }
                numberOfInput--;
            }
            Console.Read();
        }

        public static bool CheckhtmlTag(string currenthtmlTag, bool isEndText)
        {
            if (isEndText && endhtmlTags.Count() > 1)
            {
                string expected = endhtmlTags.ElementAt(endhtmlTags.Count() - 1);
                Console.WriteLine("Expected " + expected + " found #");
                return false;
            }
            else if (isEndText && endhtmlTags.Count() == 1)
            {
                string expected = endhtmlTags.Pop();
                if (currenthtmlTag != expected)
                {
                    Console.WriteLine("Expected # found " + currenthtmlTag);
                    return false;
                }
            }
            else if (!isEndText && endhtmlTags.Count() > 0)
            {
                string expected = endhtmlTags.Pop();
                if (currenthtmlTag != expected)
                {
                    Console.WriteLine("Expected " + expected + " found " + currenthtmlTag);
                    return false;
                }
            }
            else if (isEndText && endhtmlTags.Count() == 0)
            {
                Console.WriteLine("Expected # found " + currenthtmlTag);
                return false;
            }
            else
            {
                endhtmlTags.Pop();
            }
            return true;
        }

    }
}
